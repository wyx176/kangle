function goto_domain_list() 
{
	window.location = '?c=domains&a=pageList';
}
function goto_hosting_list()
{
	window.location = '?c=hosting&a=pageHost';
}